/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { FabCar } from './fabcar';
export { FabCar } from './fabcar';

export const contracts: any[] = [ FabCar ];
