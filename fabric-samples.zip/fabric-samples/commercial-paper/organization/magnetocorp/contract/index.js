/*
SPDX-License-Identifier: Apache-2.0
*/

'use strict';

const cpcontract = require('./lib/papercontract.js');
module.exports.contracts = [cpcontract];